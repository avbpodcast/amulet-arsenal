Amulet Arsenal — offline bundle
===============================

Free, open-source Bitcoin & encryption tools. Everything runs locally in your
browser. No install, no accounts, no internet needed — the only step that ever
touches the network is broadcasting a signed transaction, if you choose to.

START HERE
----------
Open this file in any browser (double-click it):

    Amulet Main/AmuletMain_v1.36.html

That launcher lists and opens every tool in this bundle. You can also open any
tool directly, e.g.  Amulet Vault/amulet_vault_v1.74.html

VERIFY (recommended)
--------------------
Each tool's SHA-256 fingerprint is in SHA256SUMS.txt. From this folder:

    Linux:    sha256sum -c SHA256SUMS.txt
    macOS:    shasum -a 256 -c SHA256SUMS.txt
    Windows:  Get-FileHash "<file>" -Algorithm SHA256   (then compare by hand)


RECOVER WITHOUT THE TOOLS
-------------------------
amulet_relic.py decrypts every password-protected file (vault.meta,
wallet .enc, Generator .enc). amulet_shamir_relic.py rebuilds a vault
from T-of-N Shamir shares, no password needed. Both are in this bundle.
Practice first on recovery-fixtures/ (throwaway data, passwords inside).
Setup: pip install cryptography argon2-cffi

How-to:  https://avbforge.com/verify.html
Source:  https://codeberg.org/avbforge/pages
License: MIT (see LICENSE)

Not your keys, not your coins. So forge them yourself.
