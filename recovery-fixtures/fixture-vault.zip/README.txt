Amulet recovery FIXTURE vault - throwaway data, never used for real funds.
Master password and wallet password: FIXTURE-throwaway-password-2026!
Seed inside: the canonical BIP-39 test mnemonic (abandon x11 + about).
